package com.example.personal.googlenewsdb.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.format.Time;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.personal.googlenewsdb.Data.GetJsonData;
import com.example.personal.googlenewsdb.Data.Source;
import com.example.personal.googlenewsdb.DetailActivity;
import com.example.personal.googlenewsdb.Favorites;
import com.example.personal.googlenewsdb.MainActivity;
import com.example.personal.googlenewsdb.R;
import com.squareup.picasso.Picasso;

import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Personal on 04-Aug-18.
 */

public class MainNewsAdapter extends RecyclerView.Adapter<MainNewsAdapter.ViewHolder> {
    ArrayList<Source> NewsData;
    Context mContext;
    View view;
    int i;
String val=null;
    Date currentdate=Calendar.getInstance().getTime();

    public MainNewsAdapter(Context context, ArrayList<Source> sources) {
        this.mContext = context;
        this.NewsData = sources;
    }

    public MainNewsAdapter(DetailActivity detailActivity, ArrayList<Source> sources, String detailActivity1) {

        this.NewsData=sources;
        this.mContext=detailActivity;
        this.val=detailActivity1;


    }

    public MainNewsAdapter(Favorites favorites, List<Source> sources, int i) {
        this.NewsData=new ArrayList<>(sources);
        this.mContext=favorites;
        this.i=i;
    }

    @Override

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

if(i==1){
    view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list2, parent, false);

}else{
    view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list1, parent, false);
}

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        if (NewsData.get(position).getUrlToImage() != null) {
            Picasso.with(mContext).load(NewsData.get(position).getUrlToImage()).into(holder.imageView);
        } else {
            holder.imageView.setImageResource(R.drawable.no_image);

        }





        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        try {
              Date pastdate=format.parse(NewsData.get(position).getPublishedAt());
               holder.PublishedDate.setText( gettime(pastdate,currentdate));

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private String gettime(Date pastdate, Date currentdate) {
        String value=null;
        long difference=currentdate.getTime()-pastdate.getTime();
        int months=(int) (difference/1000 * 60 * 60 *24 * 30);
        int numOfDays = (int) (difference / (1000 * 60 * 60 * 24));
        int hours = (int) (difference / (1000 * 60 * 60));
        int minutes = (int) (difference / (1000 * 60));
        int seconds = (int) (difference / (1000));
        if (numOfDays == 0) {

            if(hours == 0){
                if(minutes == 0){
                    value="Justnow.";
                }else{
                    value="Today at "+minutes+"M ago";
                }
            }else{
                value="Today at "+hours+"H ago";
            }


        }else{
            value=numOfDays+" D ago";
        }
        return value;
    }


    @Override
    public int getItemCount() {
        if(NewsData.size()!=0){
            return NewsData.size();

        }else{
            return 0;
        }

    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.list1Imageview)
        ImageView imageView;
        @BindView(R.id.list1PublishedDate)
        TextView PublishedDate;

        public ViewHolder(View itemView) {
            super(itemView);

            ButterKnife.bind(this, itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    onitemClick(NewsData,getAdapterPosition());
                }
            });
        }
    }

    private void onitemClick(ArrayList<Source> n, int adapterPosition) {
        String[] newsdata = new String[8];
        newsdata[0] = n.get(adapterPosition).getAuthor();
        newsdata[1] = n.get(adapterPosition).getTitle();
        newsdata[2] = n.get(adapterPosition).getDescription();
        newsdata[3] = n.get(adapterPosition).getUrl();
        newsdata[4] = n.get(adapterPosition).getUrlToImage();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        try {
            newsdata[5] = gettime(format.parse(n.get(adapterPosition).getPublishedAt()),currentdate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        newsdata[6]=n.get(adapterPosition).getName();
        newsdata[7]=n.get(adapterPosition).getName();
        Intent intent = new Intent(mContext, DetailActivity.class);
        intent.putExtra(GetJsonData.BaseLinks.MAINLY_USED_FOR_DATA_TRANSFERING_KEY, newsdata);
        mContext.startActivity(intent);
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);

    }
}

