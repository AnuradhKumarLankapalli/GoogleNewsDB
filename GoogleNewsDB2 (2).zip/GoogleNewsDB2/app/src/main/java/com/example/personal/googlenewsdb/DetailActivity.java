package com.example.personal.googlenewsdb;

import android.annotation.SuppressLint;
import android.app.LoaderManager;
import android.arch.persistence.room.Room;
import android.content.Intent;
import android.content.Loader;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.webkit.URLUtil;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.personal.googlenewsdb.Adapters.MainNewsAdapter;
import com.example.personal.googlenewsdb.Data.GetJsonData;
import com.example.personal.googlenewsdb.Data.Source;
import com.example.personal.googlenewsdb.DataBase.MyDataBase;
import com.example.personal.googlenewsdb.Service.MyIntentService;
import com.example.personal.googlenewsdb.Task.AsyncTaskData;
import com.google.android.gms.ads.InterstitialAd;
import com.like.LikeButton;
import com.like.OnAnimationEndListener;
import com.like.OnLikeListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;

public class DetailActivity extends AppCompatActivity implements
        OnAnimationEndListener,
        OnLikeListener,
        LoaderManager.LoaderCallbacks  {
    //=================================
    String[] data=new String[8];
    @BindView(R.id.DetailActivityImage)
    ImageView newsImageView;
    @BindView(R.id.date) TextView date;
    @BindView(R.id.getTitle) TextView getTitle;
    @BindView(R.id.getAuthor)
    TextView getAuthor;
    @BindView(R.id.fab) FloatingActionButton fab;
    TextToSpeech textToSpeech;
    @BindView(R.id.getdescription) TextView getDescription;
    boolean fabicon=true,favorite;
    @BindView(R.id.star_button)
    LikeButton starButton;
    @BindView(R.id.relatedNews)
    TextView related;
    @BindView(R.id.DetailActivityWebView)
    WebView webView;
    @BindView(R.id.DetailActivityColapsingToolbar)
    CollapsingToolbarLayout collapsingToolbarLayout;
    @BindView(R.id.detailrecyclerview)
    RecyclerView recyclerView;

    private InterstitialAd mInterstitialAd;
ArrayList<Source> sources=new ArrayList<>();

    MyDataBase myDataBase;
//=====================================
View parentLayout;
    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Toolbar toolbar=(Toolbar) findViewById(R.id.t);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);

        ButterKnife.bind(this);
//        MobileAds.initialize(this,
//                "ca-app-pub-3940256099942544~3347511713");
//
//        mInterstitialAd = new InterstitialAd(this);
//        mInterstitialAd.setAdUnitId("ca-app-pub-3940256099942544/1033173712");
//        mInterstitialAd.loadAd(new AdRequest.Builder().build());
//
//                if (mInterstitialAd.isLoaded()) {
//                    mInterstitialAd.show();
//                } else {
//                    Log.d("TAG", "The interstitial wasn't loaded yet.");
//                }
//
//
//        mInterstitialAd.setAdListener(new AdListener() {
//            @Override
//            public void onAdClosed() {
//                // Load the next interstitial.
//                mInterstitialAd.loadAd(new AdRequest.Builder().build());
//            }
//
//        });

        starButton.setOnAnimationEndListener(this);
        starButton.setOnLikeListener(this);
        parentLayout = findViewById(android.R.id.content);
        myDataBase= Room.databaseBuilder(this,MyDataBase.class,"google_newsdb").allowMainThreadQueries().fallbackToDestructiveMigration().build();
        textToSpeech=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                if (i != TextToSpeech.ERROR) {
                    textToSpeech.setLanguage(Locale.UK);

                }
            }
        });
        //============================
        final Intent intent = getIntent();
        data = intent.getStringArrayExtra(GetJsonData.BaseLinks.MAINLY_USED_FOR_DATA_TRANSFERING_KEY);
        Picasso.with(this).load(data[4]).into(newsImageView);
        if(data[0]!=null) {
            if (URLUtil.isValidUrl(data[0])) {

                getAuthor.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent1 = new Intent(Intent.ACTION_VIEW, Uri.parse(data[0]));
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent1.setPackage("com.android.chrome");
                        DetailActivity.this.startActivity(intent1);
                    }
                });
                getAuthor.setTextColor(Color.BLUE);
                getAuthor.setText(data[0]);
            }
            getAuthor.setText(data[0]);
        }else{
            getAuthor.setText("Not Avaliable");
        }
        getTitle.setText(data[1]);
        getDescription.setText(data[2]);
        date.setText(data[5]);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl(data[3]);
        recyclerView.setScrollBarSize(45);
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayout.HORIZONTAL,false));
                Bundle bundle=new Bundle();
                String a=GetJsonData.RelatedNews(data[1]);
                String b=GetJsonData.searchurl(a);
                bundle.putString(GetJsonData.BaseLinks.MAINLY_USED_FOR_DATA_TRANSFERING_KEY,b);
                getLoaderManager().initLoader(5,bundle,this);
                collapsingToolbarLayout.setTitle(data[6]);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(fabicon)
                {

                    Snackbar.make(view, "TextSpech is enabled", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                    fab.setImageResource(R.drawable.disablespeaker);
                    if(data[2]!=null){
                        textToSpeech.setSpeechRate(1);
                        textToSpeech.speak(data[2], TextToSpeech.QUEUE_FLUSH, null);

                    }else{
                        textToSpeech.speak("sorry there is no decription",TextToSpeech.QUEUE_FLUSH,null);
                    }
                    fabicon=false;
                }

                else
                {
                    textToSpeech.stop();
                    fab.setImageResource(R.drawable.speaker);
                    fabicon=true;
                }


            }
        });

        List<Source> testing=myDataBase.myDataBaseObject().findby(data[3]);
        if(testing.size()==1){
            {
                starButton.setLiked(true);
            }
        }else {
            starButton.setLiked(false);
        }
        Intent intent1=new Intent(DetailActivity.this, MyIntentService.class);
        intent1.putExtra(GetJsonData.BaseLinks.MAINLY_USED_FOR_DATA_TRANSFERING_KEY,data);
        intent1.setAction(GetJsonData.BaseLinks.ACTION);
        this.startService(intent1);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
            }
        });

//OnCreate ending
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(textToSpeech!=null){
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(textToSpeech!=null){
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
    }

    @Override
    public void onAnimationEnd(LikeButton likeButton) {
    }

    @Override
    public void liked(LikeButton likeButton) {
        Source source=new Source();

        source.setAuthor(data[0]);
        source.setTitle(data[1]);
        source.setDescription(data[2]);
        source.setUrl(data[3]);
        source.setUrlToImage(data[4]);
        source.setPublishedAt(data[5]);
        long a=myDataBase.myDataBaseObject().addnews(source);

        if(a>0){
            starButton.setEnabled(true);
            favorite=true;
          Snackbar.make(parentLayout,"Favourite",Snackbar.LENGTH_SHORT).show();

        }else{
            starButton.setEnabled(false);
            favorite=false;
            Snackbar.make(parentLayout,"Unable to Add.",Snackbar.LENGTH_SHORT).show();
        }
    }

    @Override
    public void unLiked(LikeButton likeButton) {
        Source source=new Source();
        source.setAuthor(data[0]);
        source.setTitle(data[1]);
        source.setDescription(data[2]);
        source.setUrl(data[3]);
        source.setUrlToImage(data[4]);
        source.setPublishedAt(data[5]);
        myDataBase.myDataBaseObject().removeFromFavourites(source);
        Snackbar.make(parentLayout,"Removed from the Favorite",Snackbar.LENGTH_SHORT).show();

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(GetJsonData.BaseLinks.MAINLY_USED_FOR_DATA_TRANSFERING_KEY,data[4]);
    }

    @Override
    public Loader onCreateLoader(int i, Bundle bundle) {
            return new AsyncTaskData(this, bundle.getString(GetJsonData.BaseLinks.MAINLY_USED_FOR_DATA_TRANSFERING_KEY));

    }

    @Override
    public void onLoadFinished(Loader loader, Object o) {

sources=GetJsonData.getData(o.toString());
if(sources.size()!=0){
    recyclerView.setAdapter(new MainNewsAdapter(this,sources,"detailActivity"));
}else{
    related.setText("No RelatedNews Here");
Snackbar.make(parentLayout,"No Related News",Snackbar.LENGTH_SHORT).show();

}


    }

    @Override
    public void onLoaderReset(Loader loader) {

    }

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();

    }
}
