package com.example.personal.googlenewsdb;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.RemoteViews;

import com.example.personal.googlenewsdb.Data.GetJsonData;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Implementation of App Widget functionality.
 */
public class HomeWidget extends AppWidgetProvider {
static  String[] data=new String[8];
    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager,
                                int appWidgetId) {

        CharSequence widgetText = context.getString(R.string.appwidget_text);
        // Construct the RemoteViews object
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.home_widget);
        views.setTextViewText(R.id.widgettitle, data[1]);
        views.setTextViewText(R.id.widgetauthor,data[0]);
        views.setTextViewText(R.id.widgetdescription,data[2]);

        try {
            URL url1=new URL(data[4]);
            HttpURLConnection httpURLConnection= (HttpURLConnection) url1.openConnection();
            InputStream inputStream=httpURLConnection.getInputStream();
            Bitmap bitmap= BitmapFactory.decodeStream(inputStream);
            views.setImageViewBitmap(R.id.imagewidget,bitmap);

        } catch (Exception e) {
            e.printStackTrace();
        }
        Intent i = new Intent(context,DetailActivity.class);
        i.putExtra(GetJsonData.BaseLinks.MAINLY_USED_FOR_DATA_TRANSFERING_KEY,data);
        i.putExtra(GetJsonData.BaseLinks.MAINLY_USED_FOR_DATA_TRANSFERING_KEY,2);
        PendingIntent pendingIntent = PendingIntent.getActivity(context,0,i,0);

            views.setOnClickPendingIntent(R.id.appwidget_layout,pendingIntent);
        // Instruct the widget manager to update the widget
        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // There may be multiple widgets active, so update all of them
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }


    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if(intent.getAction().equals(GetJsonData.BaseLinks.ACTION)){
            data=intent.getStringArrayExtra(GetJsonData.BaseLinks.MAINLY_USED_FOR_DATA_TRANSFERING_KEY);
            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
            int[] widget = appWidgetManager.getAppWidgetIds(new ComponentName(context,HomeWidget.class));

            HomeWidget.updateAppWidgets(context,appWidgetManager,widget);
        }else{

        }
    }

    private static void updateAppWidgets(Context context, AppWidgetManager appWidgetManager, int[] widget) {
        for (int appWidgetId : widget) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }

    }

    @Override
    public void onEnabled(Context context) {
        // Enter relevant functionality for when the first widget is created
    }

    @Override
    public void onDisabled(Context context) {
        // Enter relevant functionality for when the last widget is disabled
    }
}

