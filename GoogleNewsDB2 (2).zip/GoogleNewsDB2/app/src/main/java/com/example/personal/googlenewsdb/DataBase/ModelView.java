package com.example.personal.googlenewsdb.DataBase;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import com.example.personal.googlenewsdb.Data.Source;

import java.util.List;

/**
 * Created by Personal on 17-Sep-18.
 */

public class ModelView extends ViewModel {
    private MutableLiveData<List<Source>> mCurrentName=new MutableLiveData<>();

    public MutableLiveData<List<Source>> getCurrentName() {
        if (mCurrentName == null) {
            mCurrentName = new MutableLiveData<List<Source>>();
        }
        return mCurrentName;
    }

    public void setmCurrentName(List<Source> welcpme) {
        mCurrentName.setValue(welcpme);

    }

}
