package com.example.personal.googlenewsdb;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.baoyz.widget.PullRefreshLayout;
import com.example.personal.googlenewsdb.Adapters.MainNewsAdapter;
import com.example.personal.googlenewsdb.Data.GetJsonData;
import com.example.personal.googlenewsdb.Data.Source;
import com.example.personal.googlenewsdb.Task.AsyncTaskData;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity
        extends
        AppCompatActivity
        implements
        NavigationView.OnNavigationItemSelectedListener
        ,LoaderManager.LoaderCallbacks
        ,GoogleApiClient.OnConnectionFailedListener {

    //===============================
    ArrayList<Source> sources = new ArrayList<>();

    String url;
    @BindView(R.id.TopHeadlines_recyclerView)
    RecyclerView topHeadlinesRecyclerView;
    @BindView(R.id.times_india_recyclerView)
            RecyclerView timesofindiarecyclerview;
    @BindView(R.id.the_hindhu_recyclerView)
    RecyclerView hindhurecyclerview;
    @BindView(R.id.BBC_recyclerView)
            RecyclerView bbcrecyclerview;
    @BindView(R.id.CBC_recyclerView)
            RecyclerView cbcrecyclerView;
    @BindView(R.id.FOX_recyclerView)
            RecyclerView foxREcyclerView;
    @BindView(R.id.FOX_Sports_recyclerView)
            RecyclerView foxSportsRecyclerView;
    @BindView(R.id.Enter_recyclerview)
            RecyclerView EntertainmentrecyclerView;
    @BindView(R.id.GoogleNewsIndia_recyclerview)
            RecyclerView googleNewsReyclerView;

    @BindView(R.id.mainRefresh) PullRefreshLayout refreshLayout;
    @BindView(R.id.drawer_layout)DrawerLayout mainlayout;

    CircleImageView imageView;
    TextView accountmail;
    TextView accountname;
    GoogleSignInAccount account;
    GoogleApiClient googleApiClient;
//==============================

    View parentLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ButterKnife.bind(this);
        final String[] NewsUrlList = new String[9];
        NewsUrlList[0]=GetJsonData.BaseLinks.TOP_HEADLINES;
        NewsUrlList[1]=GetJsonData.BaseLinks.THE_TIMESOF_INDIA_HEADLINES;
        NewsUrlList[2]=GetJsonData.BaseLinks.THE_HINDHU_HEADLINES;
        NewsUrlList[3]=GetJsonData.BaseLinks.BBC_HEADLINES;
        NewsUrlList[4]=GetJsonData.BaseLinks.CBC_HEADLINES;
        NewsUrlList[5]=GetJsonData.BaseLinks.FOX_HEADLINES;
        NewsUrlList[6]=GetJsonData.BaseLinks.FOX_SPORT;
        NewsUrlList[7]=GetJsonData.BaseLinks.ENTERTAIMENT_HEADLINES;
        NewsUrlList[8]=GetJsonData.BaseLinks.GOOLENEWS_INDIA;


        refreshLayout.setRefreshStyle(PullRefreshLayout.STYLE_CIRCLES);
        refreshLayout.setOnRefreshListener(new PullRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                Bundle data=new Bundle();
                for(int i=0;i<9;i++){
                    data.putString(GetJsonData.BaseLinks.MAINLY_USED_FOR_DATA_TRANSFERING_KEY,NewsUrlList[i]);
                    getLoaderManager().initLoader(i,data,MainActivity.this);
                    }
                    refreshLayout.setRefreshing(false);
                }



        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState(   );

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        View view = navigationView.getHeaderView(0);
        imageView = view.findViewById(R.id.gimageview);
        accountname = view.findViewById(R.id.googleaccountname);
        accountmail = view.findViewById(R.id.googleaccountemail);




        //=======================================
         parentLayout = findViewById(android.R.id.content);
         topHeadlinesRecyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
         topHeadlinesRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
         timesofindiarecyclerview.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
         timesofindiarecyclerview.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        hindhurecyclerview.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        hindhurecyclerview.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        bbcrecyclerview.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        bbcrecyclerview.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        cbcrecyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        cbcrecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        foxREcyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        foxREcyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        foxSportsRecyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        foxSportsRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        EntertainmentrecyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        EntertainmentrecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        googleNewsReyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        googleNewsReyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));



        ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        if (conMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED
                || conMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {

            Snackbar.make(parentLayout, "Online", Snackbar.LENGTH_SHORT)
                    .setAction(null,null).show();



        } else {

            Snackbar.make(parentLayout, "No Internet Conncection", Snackbar.LENGTH_INDEFINITE).setAction("CONNECT", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS);
                    startActivity(intent);
                }
            });
        }




       Bundle data=new Bundle();

                for(int i=0;i<9;i++){
            data.putString(GetJsonData.BaseLinks.MAINLY_USED_FOR_DATA_TRANSFERING_KEY,NewsUrlList[i]);
            getLoaderManager().initLoader(i,data,MainActivity.this);

                }

runOnUiThread(new Runnable() {
    @Override
    public void run() {
        GoogleSignInOptions googleSignInOptions=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        googleApiClient=new GoogleApiClient.Builder(MainActivity.this).enableAutoManage(MainActivity.this,MainActivity.this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, googleSignInOptions).build();

    }
});



        if(getResources().getConfiguration().orientation== Configuration.ORIENTATION_LANDSCAPE){
            singinMethod();

        }else{

        }
        MainActivity.this.singinMethod();

        //oncreate ending
    }



    private void signoutMethod() {
//
//
//        Auth.GoogleSignInApi.signOut(googleApiClient);
//
//        System.exit(1);


    }

    private void singinMethod() {
        Intent intent=Auth.GoogleSignInApi.getSignInIntent(googleApiClient);
        startActivityForResult(intent,12);


    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Log.d("Welvome",""+connectionResult.getErrorMessage());
    }

    @Override
    protected void onActivityResult(final  int requestCode,final int resultCode,final Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (data != null) {
            if (requestCode == 12) {
//                GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
//                    account = result.getSignInAccount();
//                    String nameString = account.getDisplayName();
//                    String emailString = account.getEmail();
//                    Toast.makeText(this, ""+nameString+emailString, Toast.LENGTH_SHORT).show();
//                    if(account.getPhotoUrl()!=null){
//                    Picasso.with(this).load(account.getPhotoUrl().toString()).into(imageView);
//                    accountname.setText(nameString);
//                    accountmail.setText(emailString);
                }else{
//                    Picasso.with(this).load("https://lh3.googleusercontent.com/-XdUIqdMkCWA/AAAAAAAAAAI/AAAAAAAAAAA/4252rscbv5M/photo.jpg").into(imageView);                }
//                    accountname.setText(nameString);
//                    accountmail.setText(emailString);
//                    updateUi(true);

                }

        }else{
            Snackbar.make(parentLayout,"Unable to connect",Snackbar.LENGTH_LONG).show();
        }


    }
    private void updateUi(boolean b) {
        if (b){

            topHeadlinesRecyclerView.setVisibility(View.VISIBLE);
            mainlayout.setVisibility(View.VISIBLE);

        }

    }



    //==========================================


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

       if (id == R.id.nav_favorite) {

            Intent intent=new Intent(this,Favorites.class);
            this.startActivity(intent);




        } else if (id == R.id.siginout) {
            signoutMethod();


       }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;

    }


    @Override
    public Loader onCreateLoader(int i, Bundle bundle) {
        return new AsyncTaskData(this, bundle.getString(GetJsonData.BaseLinks.MAINLY_USED_FOR_DATA_TRANSFERING_KEY));
    }

    @Override
    public void onLoadFinished(Loader loader, Object o) {
        sources=GetJsonData.getData(o.toString());

        switch ( sources.get(0).getId()){
            case "google-news":topHeadlinesRecyclerView.setAdapter(new MainNewsAdapter(this,sources));
                                            break;
            case "the-times-of-india":timesofindiarecyclerview.setAdapter(new MainNewsAdapter(this,sources));
                                            break;
            case "the-hindu": hindhurecyclerview.setAdapter(new MainNewsAdapter(this,sources));
                                break;
            case "bbc-news": bbcrecyclerview.setAdapter(new MainNewsAdapter(this,sources));
                             break;
            case "cbc-news": cbcrecyclerView.setAdapter(new MainNewsAdapter(this,sources));
                             break;
            case "fox-news": foxREcyclerView.setAdapter(new MainNewsAdapter(this,sources));
                             break;
            case "fox-sports": foxSportsRecyclerView.setAdapter(new MainNewsAdapter(this,sources));
                               break;
            case "entertainment-weekly": EntertainmentrecyclerView.setAdapter(new MainNewsAdapter(this,sources));
                                         break;
            case "google-news-in": googleNewsReyclerView.setAdapter(new MainNewsAdapter(this,sources));
                                   break;


        }
    }
    @Override
    public void onLoaderReset(Loader loader) {
        }
        @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(GetJsonData.BaseLinks.MAINLY_USED_FOR_DATA_TRANSFERING_KEY,url);
    }
}