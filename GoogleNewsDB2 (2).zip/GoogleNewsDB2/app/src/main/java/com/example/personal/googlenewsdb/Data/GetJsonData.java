package com.example.personal.googlenewsdb.Data;

import android.provider.BaseColumns;

import com.example.personal.googlenewsdb.BuildConfig;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by Personal on 04-Aug-18.
 */

public  class GetJsonData {

    public  static ArrayList<Source> getData(String jsondata)   {
        ArrayList<Source>  finalJsonData=new ArrayList<>();

        try {
            JSONObject mainjson=new JSONObject(jsondata);
            String status=mainjson.getString("status");
            int totalResults=mainjson.getInt("totalResults");
            JSONArray articles=mainjson.getJSONArray("articles");
            for(int i=0;i<articles.length();i++){
                JSONObject source=articles.getJSONObject(i);
                JSONObject jsonObject=source.getJSONObject("source");



                    String id=jsonObject.getString("id");
                    String name=jsonObject.getString("name");
                    String author=source.getString("author");
                    String title=source.getString("title");
                    String description=source.getString("description");
                    String url=source.getString("url");
                    String urltoImage=source.getString("urlToImage");
                    String publishedAt=source.getString("publishedAt");

                    Source googlenews=new Source();
                    googlenews.setStatus(status);
                    googlenews.setTotalResults(totalResults);
                    googlenews.setId(id);
                    googlenews.setName(name);
                    googlenews.setAuthor(author);
                    googlenews.setTitle(title);
                    googlenews.setDescription(description);
                    googlenews.setUrl(url);
                    googlenews.setUrlToImage(urltoImage);
                    googlenews.setPublishedAt(publishedAt);




                finalJsonData.add(googlenews);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }


        return finalJsonData;
    }

    public static class  BaseLinks implements BaseColumns {
        public static final String TOP_HEADLINES="https://newsapi.org/v2/top-headlines/?sources=google-news&apiKey=059b2dbb53924b2a836f714fd6123422";
        public static final String  THE_HINDHU_HEADLINES="https://newsapi.org/v2/top-headlines?sources=the-hindu&apiKey=059b2dbb53924b2a836f714fd6123422";
        public static final String THE_TIMESOF_INDIA_HEADLINES="https://newsapi.org/v2/top-headlines?sources=the-times-of-india&apiKey=059b2dbb53924b2a836f714fd6123422";
        public static final String ENTERTAIMENT_HEADLINES="https://newsapi.org/v2/top-headlines?sources=entertainment-weekly&apiKey=059b2dbb53924b2a836f714fd6123422";
        public static final String GOOLENEWS_INDIA="https://newsapi.org/v2/top-headlines?sources=google-news-in&apiKey=059b2dbb53924b2a836f714fd6123422";
        public static final String BBC_HEADLINES="https://newsapi.org/v2/top-headlines?sources=bbc-news&apiKey=059b2dbb53924b2a836f714fd6123422";
        public static final String CBC_HEADLINES="https://newsapi.org/v2/top-headlines?sources=cbc-news&apiKey=059b2dbb53924b2a836f714fd6123422";
        public static final String FOX_HEADLINES="https://newsapi.org/v2/top-headlines?sources=fox-news&apiKey=059b2dbb53924b2a836f714fd6123422";
        public static final String FOX_SPORT="https://newsapi.org/v2/top-headlines?sources=fox-sports&apiKey=059b2dbb53924b2a836f714fd6123422";






public static final String ACTION="android";

        public static final String MAINLY_USED_FOR_DATA_TRANSFERING_KEY="helloworld";
    }
    public static  String  searchurl(String url){
        return  "https://newsapi.org/v2/everything?q="+url+"&apiKey=059b2dbb53924b2a836f714fd6123422";
    }

    public  static String RelatedNews(String url){
        return url.replaceAll(" ","%20");
    }
}
