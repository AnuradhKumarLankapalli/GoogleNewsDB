package com.example.personal.googlenewsdb.DataBase;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.personal.googlenewsdb.Data.Source;

import java.util.List;

/**
 * Created by Personal on 04-Aug-18.
 */
@Dao
public interface MyDataBaseObject {
    @Insert()
    public long addnews(Source source);
    @Query("select * from newsapi")
    List<Source> getFavouriteNews();
    @Delete
    public  void removeFromFavourites(Source source);
    @Query("SELECT * FROM newsapi WHERE url = :url")
    List<Source> findby(String url);
}
