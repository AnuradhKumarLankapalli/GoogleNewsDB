package com.example.personal.googlenewsdb;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.arch.persistence.room.Room;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;

import com.example.personal.googlenewsdb.Adapters.MainNewsAdapter;
import com.example.personal.googlenewsdb.Data.Source;
import com.example.personal.googlenewsdb.DataBase.ModelView;
import com.example.personal.googlenewsdb.DataBase.MyDataBase;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class Favorites extends AppCompatActivity {
MyDataBase myDataBase;
@BindView(R.id.favoritesrecyclerview)
    RecyclerView favrecycelerview;
ModelView mModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);
        setTitle("Favorites");
        ButterKnife.bind(this);
        myDataBase = Room.databaseBuilder(this, MyDataBase.class, "google_newsdb").allowMainThreadQueries().build();
        mModel = ViewModelProviders.of(Favorites.this).get(ModelView.class);
        mModel.setmCurrentName(myDataBase.myDataBaseObject().getFavouriteNews());
        mModel.getCurrentName().observe(Favorites.this, new Observer<List<Source>>() {
            @Override
            public void onChanged(@Nullable List<Source> sources) {
                favrecycelerview.setLayoutManager(new LinearLayoutManager(Favorites.this));
                favrecycelerview.setAdapter(new MainNewsAdapter(Favorites.this,sources,1));
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
