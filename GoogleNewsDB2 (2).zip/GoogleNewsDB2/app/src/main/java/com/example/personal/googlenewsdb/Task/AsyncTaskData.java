package com.example.personal.googlenewsdb.Task;

import android.content.AsyncTaskLoader;
import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Personal on 04-Aug-18.
 */

public class AsyncTaskData extends AsyncTaskLoader<String> {
    String link;
    Context mContext;
     public AsyncTaskData(Context context, String s) {
        super(context);
        this.mContext=context;
        this.link=s;
    }

    @Override
    protected void onStartLoading() {
        super.onStartLoading();
        forceLoad();
    }

    @Override
    public String loadInBackground() {

        StringBuilder builder=new StringBuilder();

        try {

            URL url=new URL(link);
            HttpURLConnection connection= (HttpURLConnection) url.openConnection();
            connection.connect();
            InputStream inputStream=connection.getInputStream();
            BufferedReader reader=new BufferedReader(new InputStreamReader(inputStream));
            String line="";
            while (line!=null){
                line=reader.readLine();
                builder.append(line);
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.d("haiiiiii", "loadInBackground: "+builder.length());
        return builder.toString();
    }

}
