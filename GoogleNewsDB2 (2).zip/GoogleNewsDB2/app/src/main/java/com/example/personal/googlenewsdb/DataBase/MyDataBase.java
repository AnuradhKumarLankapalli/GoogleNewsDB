package com.example.personal.googlenewsdb.DataBase;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

import com.example.personal.googlenewsdb.Data.Source;

/**
 * Created by Personal on 04-Aug-18.
 */
@Database(entities = {Source.class},version = 6,exportSchema = false)

public abstract class MyDataBase extends RoomDatabase {
    public abstract  MyDataBaseObject myDataBaseObject();
}
